package com.example.cesa;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.TextInputLayout;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btEnviar = findViewById(R.id.btEnviar);
        btEnviar.setOnClickListener(this);

        //Compruebo si ya ha introducido un CIF como prefencia
        prefs = PreferenceManager.getDefaultSharedPreferences(this);
        if (prefs.getString(getString(R.string.preferencia_cif), null) != null){

            //Al tener guardado el CIF se lo pone por defecto
            EditText etCif = findViewById(R.id.etCif);
            etCif.setText(prefs.getString("cif", null));
        }
    }

    //Infla el Action Bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cambiar_cif, menu);
        return true;
    }

    //Controla el Action Bar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.itemAjustes:
                final SharedPreferences.Editor editor = prefs.edit();

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle(R.string.titulo_cif);

                // Set up the input
                final EditText input = new EditText(this);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                input.setMaxWidth(10);
                builder.setView(input);

                builder.setPositiveButton(R.string.guardar, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        editor.putString("cif", input.getText().toString());
                        editor.commit();

                        //Al tener guardado el CIF se lo pone por defecto
                        EditText etCif = findViewById(R.id.etCif);
                        etCif.setText(prefs.getString("cif", null));
                    }
                });
                builder.setNegativeButton(R.string.cancelar, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btEnviar:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(R.string.pregunta_envio)
                        .setPositiveButton((getString(R.string.si)),
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        try {
                                            enviarFactura();
                                        } catch (ParseException | IOException e) {
                                            Toast.makeText(MainActivity.this, R.string.error_desconocido, Toast.LENGTH_LONG);
                                        }
                                    }
                                })
                        .setNegativeButton(R.string.no,
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //No hace nada
                                    }
                                });
                builder.create().show();
        }
    }

    public void validar(View v){
        //Recojo datos
        EditText etCif = findViewById(R.id.etCif);
        EditText etNum = findViewById(R.id.etNumero);
        EditText etBas = findViewById(R.id.etBase);
        EditText etIva = findViewById(R.id.etIva);
        EditText etTot = findViewById(R.id.etTotal);
        EditText etFec = findViewById(R.id.etFechaFac);
        EditText etVen = findViewById(R.id.etFechaFac);

        if (TextUtils.isEmpty(etCif.getText())) {
            toggleTextInputLayoutError(textInputEmail, getString(R.string.obligatorio));
        }

        if (TextUtils.isEmpty(etNum.getText())) {
            toggleTextInputLayoutError(textInputEmail, getString(R.string.obligatorio));
        }

        if (TextUtils.isEmpty(etBas.getText())) {
            toggleTextInputLayoutError(textInputEmail, getString(R.string.obligatorio));
        }

        if (TextUtils.isEmpty(etIva.getText())) {
            toggleTextInputLayoutError(textInputEmail, getString(R.string.obligatorio));
        }

        if (TextUtils.isEmpty(etTot.getText())) {
            toggleTextInputLayoutError(textInputEmail, getString(R.string.obligatorio));
        }

        if (TextUtils.isEmpty(etFec.getText())) {
            toggleTextInputLayoutError(textInputEmail, getString(R.string.obligatorio));
        }

        if (TextUtils.isEmpty(etVen.getText())) {
            toggleTextInputLayoutError(textInputEmail, getString(R.string.obligatorio));
        }


    }

    private void enviarFactura() throws ParseException, IOException {
        //Recojo datos
        EditText etCif = findViewById(R.id.etCif);
        EditText etRaz = findViewById(R.id.etRazon);
        EditText etDes = findViewById(R.id.etDescripcion);
        EditText etNum = findViewById(R.id.etNumero);
        EditText etBas = findViewById(R.id.etBase);
        EditText etIva = findViewById(R.id.etIva);
        EditText etTot = findViewById(R.id.etTotal);
        EditText etFec = findViewById(R.id.etFechaFac);
        EditText etVen = findViewById(R.id.etFechaFac);

        //Los meto en una factura
        Factura factura = new Factura();
        factura.setCif(String.valueOf(etCif.getText()));
        factura.setRazon(String.valueOf(etRaz.getText()));
        factura.setDescripcion(String.valueOf(etDes.getText()));
        factura.setNum(Integer.parseInt(String.valueOf(etNum.getText())));
        factura.setBase(Float.parseFloat(String.valueOf(etBas.getText())));
        factura.setIva(Float.parseFloat(String.valueOf(etIva.getText())));
        factura.setTotal(Float.parseFloat(String.valueOf(etTot.getText())));
        factura.setFechaFac(StringToDate(String.valueOf(etFec.getText())));
        factura.setFechaVen(StringToDate(String.valueOf(etVen.getText())));

        //Obtengo el fichero y lo envio por email
        Uri uri = Uri.fromFile(factura.toFile());
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/txt");

        //Agrega email o emails de destinatario.
        i.putExtra(Intent.EXTRA_EMAIL, new String[] { "email@dominio.com" });
        i.putExtra(Intent.EXTRA_SUBJECT, "Nombre fichero");
        i.putExtra(Intent.EXTRA_STREAM,  uri);
        startActivity(Intent.createChooser(i, "Enviar e-mail mediante:"));
    }

    private Date StringToDate(String cad) throws ParseException {
        Date date = new SimpleDateFormat(getString(R.string.tipo_fecha)).parse(cad);
        return date;
    }

    private static void toggleTextInputLayoutError(@NonNull TextInputLayout textInputLayout,
                                                   String msg) {
        textInputLayout.setError(msg);
        if (msg == null) {
            textInputLayout.setErrorEnabled(false);
        } else {
            textInputLayout.setErrorEnabled(true);
        }
    }
}
